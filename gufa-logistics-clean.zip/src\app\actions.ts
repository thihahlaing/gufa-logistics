'use server';

import { createClient } from '@/utils/supabase/server';
import { headers } from 'next/headers';

// Function to generate a unique order number
async function generateOrderNumber() {
  const supabase = createClient();
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  const datePrefix = `GF-${today.replace(/-/g, '')}`;

  // Find the last order number for today
  const { data, error } = await supabase
    .from('orders')
    .select('order_number')
    .like('order_number', `${datePrefix}-%`)
    .order('order_number', { ascending: false })
    .limit(1)
    .single();

  let newSequence = 1;
  if (data && data.order_number) {
    const lastSequence = parseInt(data.order_number.split('-')[2], 10);
    newSequence = lastSequence + 1;
  }

  return `${datePrefix}-${String(newSequence).padStart(3, '0')}`;
}

export async function createOrder(formData: FormData) {
  const supabase = createClient();
  const host = headers().get('host');
  const protocol = process.env.NODE_ENV === 'development' ? 'http' : 'https';

  try {
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      throw new Error('User is not authenticated');
    }

    const orderNumber = await generateOrderNumber();

    const orderData = {
      order_number: orderNumber,
      shipper_id: user.id,
      pickup_loc: formData.get('pickup_loc') as string,
      dropoff_loc: formData.get('dropoff_loc') as string,
      vehicle_type: formData.get('vehicle_type') as string,
      cargo_details: {
        description: formData.get('cargo_description') as string,
      },
      price: Number(formData.get('price')),
      status: 'PENDING', // Explicitly set status
    };

    const { data: newOrder, error } = await supabase.from('orders').insert([orderData]).select().single();

    if (error) {
      throw new Error(error.message);
    }

    // Professional Slack Notification using Block Kit
    const slackPayload = {
      attachments: [
        {
          color: "#36a64f", // Green bar
          blocks: [
            {
              type: "section",
              text: { 
                type: "mrkdwn", 
                text: `*🚀 DISPATCH ALERT: New Order #${newOrder.order_number}*`
              }
            },
            {
              type: "section",
              fields: [
                { type: "mrkdwn", text: `*Route:*
${newOrder.pickup_loc} -> ${newOrder.dropoff_loc}` },
                { type: "mrkdwn", text: `*Vehicle:*
${newOrder.vehicle_type}` },
                { type: "mrkdwn", text: `*Fare:*
${newOrder.price.toLocaleString()} MMK` },
                { type: "mrkdwn", text: `*Status:*
:large_yellow_circle: ${newOrder.status}` },
              ]
            },
            {
              type: "actions",
              elements: [
                {
                  type: "button",
                  text: { type: "plain_text", text: "View Order Details", emoji: true },
                  style: "primary",
                  url: `${protocol}://${host}/dashboard/orders/${newOrder.id}`
                }
              ]
            }
          ]
        }
      ]
    };

    // Send to our backend shield API route
    await fetch(`${protocol}://${host}/api/notify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(slackPayload),
    });

    return { success: true, orderNumber: newOrder.order_number };

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    console.error('Create Order Error:', errorMessage);
    return { success: false, error: errorMessage };
  }
}
