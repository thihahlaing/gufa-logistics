import type { Metadata } from "next";
import { Noto_Sans_Myanmar } from 'next/font/google';
import { Toaster } from 'react-hot-toast';
import "./globals.css";

const notosome = Noto_Sans_Myanmar({ 
  subsets: ['myanmar'],
  weight: ['400', '700'],
  variable: '--font-noto-sans-myanmar',
});

export const metadata: Metadata = {
  title: "Gufa Logistics",
  description: "The fastest and most reliable logistics service in Myanmar.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={notosome.variable}>
      <body>
        <Toaster 
          position="top-center"
          reverseOrder={false}
          toastOptions={{
            success: {
              duration: 3000,
              iconTheme: {
                primary: 'green',
                secondary: 'white',
              },
            },
            error: {
              duration: 5000,
            },
          }}
        />
        {children}
      </body>
    </html>
  );
}
