import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  const slackBotToken = process.env.SLACK_BOT_TOKEN;
  const slackChannel = process.env.SLACK_CHANNEL;

  if (!slackBotToken || !slackChannel) {
    console.error('Slack environment variables are not set.');
    return NextResponse.json({ error: 'Slack environment variables are not set.' }, { status: 500 });
  }

  try {
    const payload = await request.json();

    const slackResponse = await fetch('https://slack.com/api/chat.postMessage', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${slackBotToken}`,
      },
      body: JSON.stringify({
        channel: slackChannel,
        ...payload, // Spread the received payload (attachments, blocks, etc.)
      }),
    });

    const slackData = await slackResponse.json();

    if (!slackData.ok) {
      console.error('Slack API Error:', slackData.error);
      return NextResponse.json({ error: 'Failed to send Slack message', details: slackData.error }, { status: 500 });
    }

    return NextResponse.json({ message: 'Notification sent successfully' });
  } catch (error) {
    console.error('Error processing request:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
