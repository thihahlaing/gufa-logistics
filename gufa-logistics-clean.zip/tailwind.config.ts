import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        'lalamove-orange': '#F36F21',
        'gufa-blue': '#0070f3',
        'cargo-orange': '#FF8C00',
        'logistics-blue': '#0D9488',
        'big-purple': '#8B5CF6',
        'big-green': '#22C55E',
        'vivid-orange': '#FF5733',
      },
    },
  },
  plugins: [],
};
export default config;
