import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-4xl mx-auto text-center">
        <h1 className="text-5xl font-bold text-gufa-blue mb-4">Gufa Logistics</h1>
        <p className="text-2xl text-gray-600 mb-8">Yangon's Smartest Delivery Fleet</p>
        <Link href="/dashboard" className="px-8 py-3 bg-gufa-blue text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-colors duration-300">
          Get Started
        </Link>
      </div>
    </div>
  );
}
