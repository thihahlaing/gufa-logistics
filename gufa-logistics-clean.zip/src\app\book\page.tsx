'use client';

import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import type { CSSProperties } from 'react';
import { GoogleMap, useJsApiLoader, Marker, DirectionsRenderer, DirectionsService } from '@react-google-maps/api';
import { Bike, Car, Truck, X, User, Wallet, ShoppingBag, MapPin as MapPinIcon, Settings, Menu, CheckCircle, Loader2 } from 'lucide-react';

// --- MOCK Google Logo --- //
const GoogleGLogo = () => (
  <div style={{ width: '24px', height: '24px', backgroundColor: 'white', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', marginRight: '12px' }}>
    <svg width="18" height="18" viewBox="0 0 24 24">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
    </svg>
  </div>
);

const vehicleOptions = [
  { name: 'Motorbike', icon: Bike, price: 2500 },
  { name: 'Van', icon: Car, price: 8000 },
  { name: 'Truck', icon: Truck, price: 25000 },
];

const menuItems = [
    { id: 'wallet', name: 'Wallet', name_my: 'ငွေအိတ်', icon: Wallet },
    { id: 'orders', name: 'My Orders', name_my: 'ကျွန်ုပ်၏ အော်ဒါများ', icon: ShoppingBag },
    { id: 'places', name: 'Saved Places', name_my: 'အကြိုက်ဆုံးနေရာများ', icon: MapPinIcon },
    { id: 'settings', name: 'Settings', name_my: 'ဆက်တင်များ', icon: Settings },
];

const savedPlaces = [
    { name: 'Warehouse 1', address: 'Industrial Zone, Hlaingthaya' },
    { name: 'Home', address: 'No. 123, Main Road, Sanchaung' },
];

const dropoffPosition = { lat: 16.8282, lng: 96.1550 }; // Myanmar Plaza
const mapCenter = { lat: 16.8409, lng: 96.1735 }; // Yangon

const mapTheme = [
    { elementType: "geometry", stylers: [{ color: "#f5f5f5" }] },
    { elementType: "labels.icon", stylers: [{ visibility: "off" }] },
    { elementType: "labels.text.fill", stylers: [{ color: "#616161" }] },
    { elementType: "labels.text.stroke", stylers: [{ color: "#f5f5f5" }] },
    { featureType: "administrative.land_parcel", elementType: "labels.text.fill", stylers: [{ color: "#bdbdbd" }] },
    { featureType: "poi", elementType: "geometry", stylers: [{ color: "#eeeeee" }] },
    { featureType: "poi", elementType: "labels.text.fill", stylers: [{ color: "#757575" }] },
    { featureType: "poi.park", elementType: "geometry", stylers: [{ color: "#e5e5e5" }] },
    { featureType: "poi.park", elementType: "labels.text.fill", stylers: [{ color: "#9e9e9e" }] },
    { featureType: "road", elementType: "geometry", stylers: [{ color: "#ffffff" }] },
    { featureType: "road.arterial", elementType: "labels.text.fill", stylers: [{ color: "#757575" }] },
    { featureType: "road.highway", elementType: "geometry", stylers: [{ color: "#dadada" }] },
    { featureType: "road.highway", elementType: "labels.text.fill", stylers: [{ color: "#616161" }] },
    { featureType: "road.local", elementType: "labels.text.fill", stylers: [{ color: "#9e9e9e" }] },
    { featureType: "transit.line", elementType: "geometry", stylers: [{ color: "#e5e5e5" }] },
    { featureType: "transit.station", elementType: "geometry", stylers: [{ color: "#eeeeee" }] },
    { featureType: "water", elementType: "geometry", stylers: [{ color: "#c9c9c9" }] },
    { featureType: "water", elementType: "labels.text.fill", stylers: [{ color: "#9e9e9e" }] },
];

const pickupIcon = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="%2322c55e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle></svg>`;
const dropoffIcon = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="%23ef4444" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg>`;


export default function BookingPage() {
  const [selectedVehicle, setSelectedVehicle] = useState(vehicleOptions[0]);
  const [pickupLoc, setPickupLoc] = useState('');
  const [dropoffLoc, setDropoffLoc] = useState('');
  
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [showLogin, setShowLogin] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeView, setActiveView] = useState('booking'); // booking, wallet, places
  const [orderStatus, setOrderStatus] = useState('idle'); // idle, searching, assigned
  const [shouldFetchDirections, setShouldFetchDirections] = useState(true);
  
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [messages, setMessages] = useState([
    { id: 1, text: 'Hello! I am on my way to the pickup location.', sender: 'driver' },
    { id: 2, text: 'Great, thank you!', sender: 'user' },
  ]);

  // --- Map State ---
  const [map, setMap] = useState(null);
  const [directionsResponse, setDirectionsResponse] = useState(null);
  const [pickupPosition, setPickupPosition] = useState({ lat: 16.7810, lng: 96.1561 }); // Junction City
  const [carPosition, setCarPosition] = useState(pickupPosition);
  const [carPath, setCarPath] = useState([]);
  const [carPathIndex, setCarPathIndex] = useState(0);

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || "",
    libraries: ['places'],
  });

  // --- Keyframes for animations --- //
  const pulseAnimation = `
    @keyframes pulse {
      0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(243, 111, 33, 0.7); }
      70% { transform: scale(1); box-shadow: 0 0 0 20px rgba(243, 111, 33, 0); }
      100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(243, 111, 33, 0); }
    }
  `;

  useEffect(() => {
    if (orderStatus === 'searching') {
      const searchTimeout = setTimeout(() => {
        setOrderStatus('assigned');
      }, 3500);
      return () => clearTimeout(searchTimeout);
    }

    if (orderStatus === 'assigned' && carPath.length > 0) {
      const moveInterval = setInterval(() => {
        setCarPathIndex(prevIndex => {
          if (prevIndex < carPath.length - 1) {
            const nextIndex = prevIndex + 1;
            setCarPosition(carPath[nextIndex]);
            return nextIndex;
          } else {
            clearInterval(moveInterval);
            return prevIndex;
          }
        });
      }, 1000); // Move every second
      return () => clearInterval(moveInterval);
    }
  }, [orderStatus, carPath]);

  const onMapLoad = useCallback(function callback(map) {
    const bounds = new window.google.maps.LatLngBounds();
    bounds.extend(pickupPosition);
    bounds.extend(dropoffPosition);
    map.fitBounds(bounds);
    setMap(map);
  }, [pickupPosition]);

  const onUnmount = useCallback(function callback(map) {
    setMap(null);
  }, []);

  const directionsCallback = useCallback((res) => {
    if (res !== null) {
      if (res.status === 'OK') {
        setDirectionsResponse(res);
        const route = res.routes[0].overview_path;
        setCarPath(route);
        setCarPosition(route[0]);
        setCarPathIndex(0);
        setShouldFetchDirections(false);
      } else {
        console.error(`error fetching directions ${res.status}`);
      }
    }
  }, []);


  const handleMenuClick = (id) => {
      setIsMenuOpen(false);
      if (id === 'wallet' || id === 'places') {
          setActiveView(id);
      } else {
          alert(`Navigate to ${id}`);
      }
  }

  const handleBookingOrLogin = () => {
    if (!isLoggedIn) {
      setShowLogin(true);
    } else {
      setOrderStatus('searching');
    }
  };

  const handleGoogleLogin = () => {
    setShowLogin(false);
    setIsLoggedIn(true);
  };

  const handleSendMessage = (text) => {
    const newMessage = { id: messages.length + 1, text, sender: 'user' };
    setMessages(prev => [...prev, newMessage]);

    // Simulate driver response
    setTimeout(() => {
      const driverResponse = { id: messages.length + 2, text: 'Okay, I will be there soon.', sender: 'driver' };
      setMessages(prev => [...prev, driverResponse]);
    }, 1500);
  };

  const styles: { [key: string]: CSSProperties } = {
    wrapper: { maxWidth: '430px', margin: '0 auto', backgroundColor: '#f3f4f6', minHeight: '100vh', position: 'relative', fontFamily: 'sans-serif', overflow: 'hidden' },
    map: { height: '100vh', backgroundColor: '#e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px', fontWeight: 'bold', color: '#9ca3af', position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
    drawer: { position: 'absolute', bottom: 0, left: 0, right: 0, width: '100%', backgroundColor: 'white', borderTopLeftRadius: '40px', borderTopRightRadius: '40px', padding: '30px', boxShadow: '0 -10px 25px rgba(0,0,0,0.1)', transition: 'transform 0.4s ease-in-out', transform: orderStatus === 'idle' ? 'translateY(0)' : 'translateY(100%)' },
    loginDrawer: { position: 'absolute', bottom: 0, left: 0, right: 0, width: '100%', backgroundColor: 'white', borderTopLeftRadius: '40px', borderTopRightRadius: '40px', padding: '30px 20px', boxShadow: '0 -10px 25px rgba(0,0,0,0.1)', zIndex: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '60vh' },
    googleButton: { width: '90%', backgroundColor: '#4285F4', color: 'white', padding: '15px', borderRadius: '16px', border: 'none', fontSize: '18px', fontWeight: 'bold', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 14px rgba(0,0,0,0.1)' },
    button: { width: '100%', backgroundColor: '#F36F21', color: 'white', padding: '20px', borderRadius: '16px', border: 'none', fontSize: '18px', fontWeight: 'bold', marginTop: '20px', cursor: 'pointer' },
    inputContainer: { position: 'relative', width: '100%', marginBottom: '10px' },
    input: { width: '100%', border: '1px solid #e5e7eb', backgroundColor: '#f9fafb', padding: '16px', paddingRight: '40px', borderRadius: '12px', fontSize: '16px' },
    clearButton: { position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'transparent', border: 'none', cursor: 'pointer' },
    vehicleCard: { minWidth: '120px', padding: '16px', border: '2px solid #e5e7eb', borderRadius: '16px', textAlign: 'center', cursor: 'pointer', marginRight: '10px', transition: 'all 0.2s' },
    selectedVehicleCard: { border: '2px solid #F36F21', backgroundColor: '#FFF7ED' },
    avatar: { position: 'absolute', top: '20px', left: '20px', width: '50px', height: '50px', borderRadius: '50%', backgroundColor: '#F36F21', cursor: 'pointer', zIndex: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 10px rgba(0,0,0,0.2)' },
    sideMenu: { position: 'fixed', top: 0, left: 0, bottom: 0, width: '300px', backgroundColor: 'white', zIndex: 30, boxShadow: '5px 0 25px rgba(0,0,0,0.1)', transform: isMenuOpen ? 'translateX(0)' : 'translateX(-100%)', transition: 'transform 0.3s ease-in-out', padding: '40px 20px' },
    menuBackdrop: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.4)', zIndex: 29, transition: 'opacity 0.3s ease-in-out', opacity: isMenuOpen ? 1 : 0, pointerEvents: isMenuOpen ? 'auto' : 'none' },
    menuItem: { display: 'flex', alignItems: 'center', padding: '15px 10px', borderRadius: '12px', cursor: 'pointer', marginBottom: '10px' },
    pageOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'white', zIndex: 15, padding: '20px', transform: activeView === 'booking' ? 'translateY(100%)' : 'translateY(0)', transition: 'transform 0.3s ease-in-out' },
    backButton: { marginBottom: '20px', fontWeight: 'bold', cursor: 'pointer' },
    walletCard: { backgroundColor: '#F36F21', color: 'white', padding: '30px', borderRadius: '24px', textAlign: 'center', boxShadow: '0 10px 20px rgba(243, 111, 33, 0.4)' },
    topUpButton: { width: '100%', backgroundColor: 'white', color: '#F36F21', padding: '15px', borderRadius: '12px', border: 'none', fontSize: '16px', fontWeight: 'bold', marginTop: '20px', cursor: 'pointer' },
    placeItem: { padding: '20px', border: '1px solid #e5e7eb', borderRadius: '16px', marginBottom: '15px', cursor: 'pointer' },
    
    // --- Order Status Styles ---
    orderStatusContainer: { position: 'absolute', bottom: 0, left: 0, right: 0, width: '100%', backgroundColor: 'white', borderTopLeftRadius: '40px', borderTopRightRadius: '40px', padding: '30px', boxShadow: '0 -10px 25px rgba(0,0,0,0.1)', transition: 'transform 0.4s ease-in-out', transform: orderStatus !== 'idle' ? 'translateY(0)' : 'translateY(100%)' },
    radarContainer: { display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '35vh' },
    radarPulse: { width: '100px', height: '100px', borderRadius: '50%', backgroundColor: '#F36F21', display: 'flex', alignItems: 'center', justifyContent: 'center', animation: 'pulse 2s infinite' },
    driverCard: { padding: '20px', backgroundColor: '#f9fafb', borderRadius: '24px' },
    carIcon: { zIndex: 5 },

    // --- Chat Styles ---
    chatOverlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'white', zIndex: 40, transform: isChatOpen ? 'translateY(0)' : 'translateY(100%)', transition: 'transform 0.3s ease-in-out', display: 'flex', flexDirection: 'column' },
    chatHeader: { padding: '20px', display: 'flex', alignItems: 'center', borderBottom: '1px solid #e5e7eb' },
    chatMessages: { flex: 1, padding: '20px', overflowY: 'auto', backgroundColor: '#f9fafb' },
    messageBubble: { maxWidth: '75%', padding: '12px 16px', borderRadius: '20px', marginBottom: '10px' },
    userMessage: { backgroundColor: '#F36F21', color: 'white', alignSelf: 'flex-end', borderBottomRightRadius: '4px' },
    driverMessage: { backgroundColor: '#e5e7eb', color: '#1f2937', alignSelf: 'flex-start', borderBottomLeftRadius: '4px' },
    chatInputContainer: { padding: '20px', borderTop: '1px solid #e5e7eb', backgroundColor: 'white' },
    quickReplyContainer: { display: 'flex', gap: '10px', marginBottom: '15px' },
    quickReplyButton: { flex: 1, padding: '12px', borderRadius: '12px', border: '1px solid #e5e7eb', backgroundColor: '#f9fafb', cursor: 'pointer' },
  };

  return (
    <div style={styles.wrapper}>
      {isLoggedIn && (
        <div style={styles.avatar} onClick={() => setIsMenuOpen(true)}>
          <User size={28} color="white" />
        </div>
      )}

      {isMenuOpen && <div style={styles.menuBackdrop} onClick={() => setIsMenuOpen(false)}></div>}

      <div style={styles.sideMenu}>
        <div style={{display: 'flex', alignItems: 'center', marginBottom: '40px'}}>
            <div style={{...styles.avatar, position: 'static', width: '60px', height: '60px'}}><User size={32} color="white" /></div>
            <div style={{marginLeft: '15px'}}>
                <p style={{fontWeight: 'bold', fontSize: '18px'}}>User Name</p>
                <p style={{color: '#6b7280', fontSize: '14px'}}>View Profile</p>
            </div>
        </div>
        {menuItems.map(item => (
            <div key={item.id} style={styles.menuItem} onClick={() => handleMenuClick(item.id)} onMouseOver={(e) => e.currentTarget.style.backgroundColor='#f3f4f6'} onMouseOut={(e) => e.currentTarget.style.backgroundColor='transparent'}>
                <item.icon size={24} color="#4b5563" style={{marginRight: '20px'}} />
                <div>
                    <p style={{fontWeight: '600', color: '#1f2937'}}>{item.name}</p>
                    <p style={{color: '#6b7280', fontSize: '14px'}}>{item.name_my}</p>
                </div>
            </div>
        ))}
      </div>

      <div style={styles.map}>
        {!isLoaded ? (
          <p>Loading Map...</p>
        ) : (
          <GoogleMap
            mapContainerStyle={{width: '100%', height: '100%'}}
            center={mapCenter}
            zoom={13}
            options={{ disableDefaultUI: true, styles: mapTheme }}
            onLoad={onMapLoad}
            onUnmount={onUnmount}
          >
            <Marker 
              position={pickupPosition} 
              draggable={true}
              onDragEnd={(e) => {
                const newPos = { lat: e.latLng.lat(), lng: e.latLng.lng() };
                setPickupPosition(newPos);
                setShouldFetchDirections(true);
                if (map) {
                  const bounds = new window.google.maps.LatLngBounds();
                  bounds.extend(newPos);
                  bounds.extend(dropoffPosition);
                  map.fitBounds(bounds);
                }
              }}
              icon={pickupIcon}
            />
            <Marker 
              position={dropoffPosition} 
              icon={dropoffIcon}
            />

            {shouldFetchDirections && (
              <DirectionsService
                options={{ 
                  destination: dropoffPosition,
                  origin: pickupPosition,
                  travelMode: 'DRIVING'
                }}
                callback={directionsCallback}
              />
            )}

            {directionsResponse && <DirectionsRenderer options={{ directions: directionsResponse, suppressMarkers: true, polylineOptions: { strokeColor: '#0000FF', strokeWeight: 5 } }} />}

            {orderStatus === 'assigned' && carPosition && (
              <Marker
                position={carPosition}
                icon={{
                  url: 'https://cdn-icons-png.flaticon.com/64/741/741407.png', // Simple car icon
                  scaledSize: new window.google.maps.Size(40, 40),
                  anchor: new window.google.maps.Point(20, 20),
                }}
                title="Gufa Driver"
              />
            )}
          </GoogleMap>
        )}
      </div>

      {/* --- Functional Views Overlay --- */}
      <div style={{...styles.pageOverlay, ...(activeView === 'booking' && {transform: 'translateY(100%)'})}}>
        <p style={styles.backButton} onClick={() => setActiveView('booking')}>&larr; Back to Booking</p>
        {activeView === 'wallet' && (
            <div>
                <h2 style={{fontSize: '28px', fontWeight: 'bold', marginBottom: '20px'}}>My Wallet</h2>
                <div style={styles.walletCard}>
                    <p style={{fontSize: '16px', opacity: 0.8}}>Current Balance</p>
                    <p style={{fontSize: '48px', fontWeight: 'bold', margin: '10px 0'}}>5,000 <span style={{fontSize: '24px'}}>MMK</span></p>
                </div>
                <button style={styles.topUpButton}>Top Up Balance</button>
            </div>
        )}
        {activeView === 'places' && (
            <div>
                <h2 style={{fontSize: '28px', fontWeight: 'bold', marginBottom: '20px'}}>Saved Places</h2>
                {savedPlaces.map(place => (
                    <div key={place.name} style={styles.placeItem} onClick={() => { setPickupLoc(place.address); setActiveView('booking'); }}>
                        <p style={{fontWeight: 'bold', fontSize: '18px'}}>{place.name}</p>
                        <p style={{color: '#6b7280'}}>{place.address}</p>
                    </div>
                ))}
            </div>
        )}
      </div>

      {showLogin && (
        <div style={styles.loginDrawer}>
            <h2 style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '10px', color: '#1f2937' }}>Welcome to Gufa</h2>
            <p style={{ fontSize: '16px', color: '#6b7280', marginBottom: '40px' }}>Sign in to continue your booking</p>
            <button onClick={handleGoogleLogin} style={styles.googleButton}>
                <GoogleGLogo />
                Sign in with Google
            </button>
        </div>
      )}

      <div style={{...styles.drawer, transform: orderStatus === 'idle' && activeView === 'booking' && !showLogin ? 'translateY(0)' : 'translateY(100%)' }}>
        <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '20px' }}>Place Your Order</h2>
        
        <div>
          <div style={styles.inputContainer}>
            <input type="text" placeholder="ဘယ်က ပစ္စည်းယူမလဲ?" style={styles.input} value={pickupLoc} onChange={(e) => setPickupLoc(e.target.value)} />
            {pickupLoc && <button onClick={() => setPickupLoc('')} style={styles.clearButton}><X size={20} color="#9ca3af" /></button>}
          </div>
          <div style={styles.inputContainer}>
            <input type="text" placeholder="ဘယ်ကို ပို့မလဲ?" style={styles.input} value={dropoffLoc} onChange={(e) => setDropoffLoc(e.target.value)} />
            {dropoffLoc && <button onClick={() => setDropoffLoc('')} style={styles.clearButton}><X size={20} color="#9ca3af" /></button>}
          </div>
        </div>

        <div style={{ display: 'flex', overflowX: 'auto', padding: '16px 0' }}>
          {vehicleOptions.map((vehicle) => {
            const isSelected = selectedVehicle.name === vehicle.name;
            return (
              <div key={vehicle.name} onClick={() => setSelectedVehicle(vehicle)} style={{ ...styles.vehicleCard, ...(isSelected && styles.selectedVehicleCard) }}>
                <vehicle.icon size={48} style={{ marginBottom: '8px', color: isSelected ? '#F36F21' : '#4b5563' }} />
                <p style={{ fontWeight: 'bold' }}>{vehicle.name}</p>
                <p style={{ fontSize: '14px', color: '#6b7280' }}>{vehicle.price.toLocaleString()} MMK</p>
              </div>
            );
          })}
        </div>

        <button onClick={handleBookingOrLogin} style={styles.button}>
          {isLoggedIn ? `Confirm Booking | ${selectedVehicle.price.toLocaleString()} MMK` : 'Proceed to Book'}
        </button>
      </div>

      {/* --- Order Status Drawer --- */}
      <div style={{...styles.orderStatusContainer, transform: orderStatus !== 'idle' ? 'translateY(0)' : 'translateY(100%)' }}>
        {orderStatus === 'searching' && (
          <div style={styles.radarContainer}>
            <div style={styles.radarPulse}>
              <Car size={40} color="white" />
            </div>
            <p style={{fontWeight: 'bold', fontSize: '18px', marginTop: '20px'}}>Searching for your Gufa Driver...</p>
            <p style={{fontSize: '16px', color: '#6b7280'}}>သင့်အတွက် Gufa Driver ကို ရှာဖွေနေသည်...</p>
          </div>
        )}
        {orderStatus === 'assigned' && (
          <div>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '20px' }}>Driver on the way!</h2>
            <div style={styles.driverCard}>
              <div style={{display: 'flex', alignItems: 'center'}}>
                <div style={{width: '60px', height: '60px', borderRadius: '50%', backgroundColor: '#e5e7eb', marginRight: '15px', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><User size={32} color="#4b5563" /></div>
                <div>
                  <p style={{fontWeight: 'bold', fontSize: '18px'}}>U Kyaw Kyaw</p>
                  <p style={{color: '#6b7280'}}>White Toyota Probox (YGN-1234)</p>
                </div>
              </div>
              <div style={{display: 'flex', marginTop: '20px', gap: '10px'}}>
                <button style={{...styles.button, flex: 1, backgroundColor: '#22c55e', marginTop: 0}}>Call Driver</button>
                <button onClick={() => setIsChatOpen(true)} style={{...styles.button, flex: 1, backgroundColor: '#3b82f6', marginTop: 0}}>Message</button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* --- Chat Overlay --- */}
      <div style={styles.chatOverlay}>
        <div style={styles.chatHeader}>
            <p style={styles.backButton} onClick={() => setIsChatOpen(false)}>&larr; Back</p>
            <div style={{marginLeft: '15px'}}>
                <p style={{fontWeight: 'bold', fontSize: '18px'}}>U Kyaw Kyaw</p>
                <p style={{color: '#6b7280', fontSize: '14px'}}>Online</p>
            </div>
        </div>
        <div style={styles.chatMessages}>
            <div style={{display: 'flex', flexDirection: 'column', gap: '10px'}}>
            {messages.map(msg => (
                <div key={msg.id} style={{...styles.messageBubble, ...(msg.sender === 'user' ? styles.userMessage : styles.driverMessage), alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start'}}>
                    {msg.text}
                </div>
            ))}
            </div>
        </div>
        <div style={styles.chatInputContainer}>
            <div style={styles.quickReplyContainer}>
                <button onClick={() => handleSendMessage('ကျွန်တော်လာနေပါပြီ')} style={styles.quickReplyButton}>ကျွန်တော်လာနေပါပြီ</button>
                <button onClick={() => handleSendMessage('ခဏစောင့်ပေးပါ')} style={styles.quickReplyButton}>ခဏစောင့်ပေးပါ</button>
                <button onClick={() => handleSendMessage('ဘယ်မှာလဲဗျ?')} style={styles.quickReplyButton}>ဘယ်မှာလဲဗျ?</button>
            </div>
        </div>
      </div>

    </div>
  );
}
