DROP TABLE IF EXISTS public.orders;

CREATE TABLE public.orders (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    shipper_id uuid NOT NULL,
    pickup_loc text NOT NULL,
    dropoff_loc text NOT NULL,
    vehicle_type text NOT NULL,
    cargo_details jsonb,
    price numeric NOT NULL,
    status text NOT NULL DEFAULT 'pending'::text,
    driver_id uuid,
    CONSTRAINT orders_pkey PRIMARY KEY (id),
    CONSTRAINT orders_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.profiles(id) ON DELETE SET NULL,
    CONSTRAINT orders_shipper_id_fkey FOREIGN KEY (shipper_id) REFERENCES public.profiles(id) ON DELETE CASCADE,
    CONSTRAINT orders_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'accepted'::text, 'picking_up'::text, 'delivered'::text, 'cancelled'::text])))
);

-- Enable RLS
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Enable read access for all users" ON "public"."orders" FOR SELECT USING (true);
CREATE POLICY "Enable insert for authenticated users only" ON "public"."orders" FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Enable update for users based on user_id" ON "public"."orders" FOR UPDATE USING (auth.uid() = shipper_id OR auth.uid() = driver_id) WITH CHECK (auth.uid() = shipper_id OR auth.uid() = driver_id);
CREATE POLICY "Enable delete for users based on user_id" ON "public"."orders" FOR DELETE USING (auth.uid() = shipper_id);
