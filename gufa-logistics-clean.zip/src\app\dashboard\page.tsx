'use client';

import Link from 'next/link';
import { Home, List, User } from 'lucide-react';

function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col justify-center items-center font-sans">
      <div className="relative w-full max-w-md mx-auto bg-white shadow-lg rounded-2xl overflow-hidden" style={{ height: '812px' }}>
        <div className="p-8">
          <h1 className="text-3xl font-bold text-logistics-blue text-center mb-12">Gufa Logistics</h1>

          <div className="space-y-6">
            <Link href="/book" className="block p-8 bg-big-purple rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300">
              <div className="text-center text-white">
                <span className="text-5xl">📦</span>
                <h2 className="text-2xl font-bold mt-4">ကျွန်ုပ် ပစ္စည်းပို့ချင်သည်</h2>
                <p className="font-light">(I want to Ship)</p>
              </div>
            </Link>

            <button
              onClick={() => alert('Coming soon!')}
              className="w-full p-8 bg-big-green rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300"
            >
              <div className="text-center text-white">
                <span className="text-5xl">🚛</span>
                <h2 className="text-2xl font-bold mt-4">ကျွန်ုပ် ကားမောင်းချင်သည်</h2>
                <p className="font-light">(I want to Drive)</p>
              </div>
            </button>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-200">
          <div className="flex justify-around py-4">
            <Link href="/dashboard" className="flex flex-col items-center text-logistics-blue">
              <Home className="w-7 h-7" />
              <span className="text-xs mt-1">Home</span>
            </Link>
            <Link href="#" className="flex flex-col items-center text-gray-400 hover:text-logistics-blue">
              <List className="w-7 h-7" />
              <span className="text-xs mt-1">Orders</span>
            </Link>
            <Link href="#" className="flex flex-col items-center text-gray-400 hover:text-logistics-blue">
              <User className="w-7 h-7" />
              <span className="text-xs mt-1">Profile</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
